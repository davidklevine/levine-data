Guide to the files

codebook.txt documents the hbmetadata.csv/fkmeta.csv, xxmatrices.csv, xxtreatments.csv, xxdata.csv files

hbmetadata.csv, hbmatrices.csv, hbtreatments, hbdata.csv from human behavior database taken from Dalbo-Frechette metastudy

fknew.csv from Fudenberg-Rehbinder metastudy

more_data.xx.txt creates fkmeta.csv, fkmatrices.csv, fktreatments.csv, fkdata.csv from fknew.csv

mats.csv matches treatments, created by hand from output of memories-get-mat.xx.txt, rep shows which treatments replicate each other, fr indicates Fudenberg-Rehbinder metastudy: there each match is reported twice

coop.xx.csv welfare against cooperation; computed in new.mem.xxx.txt and copied by hand

monte.xx.txt does the monte-carlo to compute predicted values for the Fudenberg-Rehbinder model

new.mem.xx.txt main program, computes statistics from the data and the welfare optimum along with ancillary statistics

new.mem.phi.xxx.txt computes mean absolute error for different values of phi

new.sum.xx.txt computes cooperation rates from the data

new.sym.xx.txt computes best strongly symmetric equilibrium

monotone.xx.csv built by hand using data from monte.xx.txt and new.mem.xxx.txt, used by monotone.xx.txt

monotone.xx.txt conducts regressions, builds all figures

level1.xx.txt computes the best responses to a uniform over all memory one strategies

phi.table.xx.txt computes the mean absolute errors for different values of phi

se.xx.txt computes standard error upper bounds based on number of initial period matches

new.mem.semi.xx.txt computes the semi-grim equilibria

cond.xx.csv contains the empirical conditional strategies for use in new.mem.semi.xx.txt


