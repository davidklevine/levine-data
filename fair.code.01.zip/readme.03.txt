note that numbers in file names are version numbers
r.calc.p.new.txt main routine for reporting and solving public good with and without punishment
r.calc.p.group.txt reports the data disaggregated into groups for public goods with punishment
r.cal.main.txt main routine for reporting and solving ultimatum bargaining
r.calc.main.five.txt r.cal.main.txt modified so that noise players never offer more than five
unreasonable.ods punishment contributions assuming uniform distribution
gamma.new.ods provides the graph of how contributions decline over time
van-huck-data.ods analyzes data from stag hunt
risk.txt calibrates and plots the risk averse utility functions
inverse-gneezy.lyx some equation used in risk.txt
vh-monte.txt computes stag-hunt (theoretical) welfare by Monte Carlo for the large population case
vh-welfare-two.txt for the small populationcase
van-huck-data.csv stag hunt data
fs.txt Fehr-Schmidt ultimatum calculations
confidence.txt ultimatum empirical good offers and rejections rates
nikiforakis_normann_data_2008_expe.csv individual level data from Nikiforakis and Normann
df1999raw.csv individual level data from Duffy and Feltovitch
gift.txt main analysis of gift exchange game
gift.ran.txt supplementary analysis of robot optimum in gift exchange game
charness.csv individual level from Charness
charn_fs.txt Fehr-Schmidt for Charness data
